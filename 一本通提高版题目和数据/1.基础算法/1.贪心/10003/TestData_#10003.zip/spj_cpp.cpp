// Author: HeRaNO
#include "testlib.h"
#include <algorithm>
#define MAXN 1005

int n, A[MAXN], B[MAXN], s[MAXN], p[MAXN], ta, tb;
int pans, jans;

int main(int argc, char *argv[])
{
	registerTestlibCmd(argc, argv);
	n = inf.readInt();
	for (int i = 1; i <= n; i++) A[i] = inf.readInt();
	for (int i = 1; i <= n; i++) B[i] = inf.readInt();
	pans = ouf.readInt();
	jans = ans.readInt();
	if (pans != jans)
		quitf(_wa, "Wrong Answer. Expected = %d, found = %d", jans, pans);
	for (int i = 1; i <= n; i++)
	{
		s[i] = ouf.readInt(1, n);
		p[i] = s[i];
	}
	std::sort(p + 1, p + n + 1);
	for (int i = 1; i <= n; i++)
		if (p[i] != i)
			quitf(_wa, "Incorrect sequence: same elements in the sequence.");
	for (int i = 1; i <= n; i++)
	{
		ta += A[s[i]];
		if (tb < ta) tb = ta;
		tb += B[s[i]];
	}
	if (tb != pans) quitf(_wa, "Incorrect sequence, your real time: %d", tb);
	else quitf(_ok, "Acceptable answer.");
	return 0;
}
